# CrispChat_Typecho
在Typecho增加CrispChat客服入口，方便在线交流
<h3>版本号:1.0.0 <a href="https://github.com/whitebearcode/CrispChat_Typecho/releases/download/1.0.0/CrispChat_v1.0.0.zip">戳这里下载最新版本</a></h3>
<br>
<li>本插件免费开源，持续更新</li>
<li>我的博客:<a href="https://www.coder-bear.com">戳这里</a></li>
<li>问题反馈社区:<a href="https://support.qq.com/products/314782">戳这里</a></li>
<li>交流群:561848356</li>
  
